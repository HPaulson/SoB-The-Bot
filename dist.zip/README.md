# SoB: The Bot

SoB: The Bot was used to predict scores and allocate xp (points) to members for correct predictions on the Official Sons Of Ben Discord guild during the 2020 MLS Is Back competition. The API used in this application is the Official MLS match data API scrapped from MLSSoccer.com and the MLS mobile application with the help of WireShark and Chrome Development Tools.

> This Discord Application uses [SeismicCore]'s ClientCore Mini, and is not licensed for use or modifacation of any kind unless specifically granted by SeismicCore and Hunter Paulson. To request permission to use or modify this application, please open an issue with details of your request.

[seismiccore]: https://github.com/seismiccore"
